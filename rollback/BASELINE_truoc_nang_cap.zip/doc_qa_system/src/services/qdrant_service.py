"""Quản lý collection Qdrant, embedding (litellm) và tìm kiếm vector."""
from __future__ import annotations

import asyncio
import threading
import uuid
from dataclasses import dataclass
from typing import Any, Optional, Sequence

import litellm
from qdrant_client import QdrantClient
from qdrant_client.http import models as qm

from src.config import Settings, get_settings
from src.services.logger_service import get_logger

logger = get_logger("qdrant")
litellm.drop_params = True  # bỏ qua tham số mà provider không hỗ trợ


class EmbeddingError(Exception):
    """Lỗi gọi API embedding."""


@dataclass
class Hit:
    id: str
    score: float
    payload: dict[str, Any]


def _point_id(filename: str, chunk_index: int) -> str:
    """ID xác định -> nạp lại cùng file sẽ ghi đè thay vì nhân đôi."""
    return str(uuid.uuid5(uuid.NAMESPACE_URL, f"{filename}:{chunk_index}"))


def _match_any(key: str, values: Sequence[str]) -> qm.FieldCondition:
    return qm.FieldCondition(key=key, match=qm.MatchAny(any=list(values)))


def _match(key: str, value: str) -> qm.FieldCondition:
    return qm.FieldCondition(key=key, match=qm.MatchValue(value=value))


class QdrantService:
    def __init__(self, settings: Optional[Settings] = None) -> None:
        self._s = settings or get_settings()
        if self._s.qdrant_path:
            self.client = QdrantClient(path=self._s.qdrant_path)
        else:
            self.client = QdrantClient(
                host=self._s.qdrant_host,
                port=self._s.qdrant_port,
                api_key=self._s.qdrant_api_key or None,
                timeout=30,
            )
        self._ready = False
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ setup
    def ensure_collection(self) -> None:
        """Tạo collection + payload index nếu chưa có (lazy, gọi lại an toàn)."""
        if self._ready:
            return
        with self._lock:
            if self._ready:
                return
            name = self._s.qdrant_collection
            if not self.client.collection_exists(name):
                self.client.create_collection(
                    collection_name=name,
                    vectors_config=qm.VectorParams(size=self._s.embedding_dim, distance=qm.Distance.COSINE),
                )
                logger.info("Created Qdrant collection '%s' (dim=%d)", name, self._s.embedding_dim)
            else:
                try:
                    vectors = self.client.get_collection(name).config.params.vectors
                    size = getattr(vectors, "size", None)
                    if size and size != self._s.embedding_dim:
                        logger.error(
                            "Collection '%s' có dim=%s nhưng EMBEDDING_DIM=%d -> hãy đổi tên collection hoặc dim",
                            name, size, self._s.embedding_dim,
                        )
                except Exception as exc:  # noqa: BLE001
                    logger.warning("Không kiểm tra được dim của collection: %s", exc)
            for field_name in ("doc_number", "filename"):
                try:
                    self.client.create_payload_index(
                        collection_name=name, field_name=field_name, field_schema=qm.PayloadSchemaType.KEYWORD
                    )
                except Exception as exc:  # noqa: BLE001 (index đã tồn tại / local mode)
                    logger.debug("Payload index '%s': %s", field_name, exc)
            self._ready = True

    def ping(self) -> bool:
        try:
            self.client.get_collections()
            return True
        except Exception:  # noqa: BLE001
            return False

    # -------------------------------------------------------------- embedding
    async def embed_texts(self, texts: list[str], batch_size: int = 64) -> list[list[float]]:
        vectors: list[list[float]] = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i : i + batch_size]
            max_retries, base_delay = 4, 2.0
            for attempt in range(max_retries):
                try:
                    resp = await litellm.aembedding(
                        model=self._s.embedding_model,
                        input=batch,
                        dimensions=self._s.embedding_dim,
                    )
                    vectors.extend([item["embedding"] for item in resp.data])
                    break
                except Exception as exc:  # noqa: BLE001
                    err_str = str(exc)
                    is_retryable = any(c in err_str for c in ["503", "429", "ServiceUnavailable", "RateLimitError", "UNAVAILABLE", "RESOURCE_EXHAUSTED"])
                    if is_retryable and attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt)
                        logger.warning("Embedding API transient error (attempt %d/%d), retrying in %.0fs", attempt + 1, max_retries, delay)
                        await asyncio.sleep(delay)
                        continue
                    logger.error("Embedding API error: %s", exc)
                    hint = ""
                    if any(k in err_str for k in ("401", "AuthenticationError", "invalid_api_key", "API key")):
                        hint = (f" [Gợi ý: khoá API không hợp lệ cho EMBEDDING_MODEL='{self._s.embedding_model}'. "
                                "Kiểm tra file .env: khoá tương ứng đã điền thật chưa và EMBEDDING_MODEL có đúng nhà cung cấp không "
                                "(model Gemini phải có tiền tố 'gemini/')]")
                    raise EmbeddingError(f"Lỗi gọi API embedding: {exc}{hint}") from exc
        if len(vectors) != len(texts):
            raise EmbeddingError("Số vector trả về không khớp số văn bản đầu vào")
        return vectors

    # ------------------------------------------------------------------ write
    def delete_by_filename(self, filename: str) -> None:
        self.ensure_collection()
        self.client.delete(
            collection_name=self._s.qdrant_collection,
            points_selector=qm.FilterSelector(filter=qm.Filter(must=[_match("filename", filename)])),
            wait=True,
        )

    def replace_document(
        self, filename: str, payloads: list[dict[str, Any]], vectors: list[list[float]]
    ) -> int:
        """Xoá chunk cũ của file rồi upsert chunk mới."""
        self.ensure_collection()
        self.delete_by_filename(filename)
        points = [
            qm.PointStruct(id=_point_id(filename, p["chunk_index"]), vector=v, payload=p)
            for p, v in zip(payloads, vectors)
        ]
        for i in range(0, len(points), 100):
            self.client.upsert(collection_name=self._s.qdrant_collection, points=points[i : i + 100], wait=True)
        return len(points)

    def set_doc_payload(self, doc_number: str, payload: dict[str, Any]) -> None:
        """Cập nhật metadata (amended_by, status, ...) cho MỌI chunk của một văn bản."""
        self.ensure_collection()
        self.client.set_payload(
            collection_name=self._s.qdrant_collection,
            payload=payload,
            points=qm.Filter(must=[_match("doc_number", doc_number)]),
            wait=True,
        )

    # ------------------------------------------------------------------- read
    def search(
        self, vector: list[float], limit: int, doc_numbers: Optional[Sequence[str]] = None
    ) -> list[Hit]:
        self.ensure_collection()
        flt = qm.Filter(must=[_match_any("doc_number", doc_numbers)]) if doc_numbers else None
        result = self.client.query_points(
            collection_name=self._s.qdrant_collection,
            query=vector,
            limit=limit,
            query_filter=flt,
            with_payload=True,
        )
        return [Hit(id=str(p.id), score=float(p.score), payload=dict(p.payload or {})) for p in result.points]

    def scroll_doc(self, doc_number: str) -> list[Hit]:
        """Lấy TOÀN BỘ chunk của một văn bản (chỉ payload, không vector), sắp theo chunk_index. Không tốn embedding/LLM."""
        self.ensure_collection()
        flt = qm.Filter(must=[_match("doc_number", doc_number)])
        out: list[Hit] = []
        offset = None
        while True:
            points, offset = self.client.scroll(
                collection_name=self._s.qdrant_collection, scroll_filter=flt, limit=256,
                offset=offset, with_payload=True, with_vectors=False,
            )
            out.extend(Hit(id=str(pt.id), score=0.0, payload=dict(pt.payload or {})) for pt in points)
            if offset is None:
                break
        out.sort(key=lambda h: h.payload.get("chunk_index", 0))
        return out

    def count(self) -> int:
        self.ensure_collection()
        return self.client.count(collection_name=self._s.qdrant_collection, exact=True).count
